# PHP-Database-connection
[![GitHub license](https://img.shields.io/github/license/shauryauppal/PHP-Database-connection.svg)](https://github.com/shauryauppal/PHP-Database-connection/blob/master/LICENSE) [![MADEIN](https://img.shields.io/badge/MADE%20IN-PHP-blue.svg)](https://github.com/shauryauppal/PHP-Database-connection) [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com) [![HitCount](http://hits.dwyl.io/shauryauppal/PHP-Database-connection.svg)](https://github.com/shauryauppal/PHP-Database-connection)

## Guide for PHP and SQL connection with HTML form.

## Database1
 + This PHP code is to connect to PHP to SQL and Create a database.
*********************
## Database2
   + Connects SQL
   + Select already created database
   + Create a table for the database
*************
## Database3
   + Inserting values into the table created.
***************
## Database4
+ Fetch data from HTML form and store the data entered in the form to SQL database table created.
**************
## Database5
+ Displays the data store in SQL database table.
+ mysql_fetch_array, fetch the data from SQL table and prints it on the webpage.

**************
## Database6
+ Login with username and password to the user table in the db.
+ Uses POST requests containing the required fields.

**************

## Form.html
+ It is the HTML form in which data is entered that gets stored in SQL database table.

********************
## db.php
+ It is a connection file that helps you not to write your connection and selection on database code again and again. We simply include this file in our PHP code for connection.
**********************************
