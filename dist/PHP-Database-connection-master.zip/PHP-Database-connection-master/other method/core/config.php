<?php

return  [
    'DATABASE' => 'myDatabase',
    'USER' => 'root',
    'PASSWORD' => 'myPassword',
    'HOST' => 'localhost',
    'PORT' => '3306',
];
