<!DOCTYPE html>
<html>
<head>
<title>
SHAURYA</title>
</head>

<body style="background-color:pink">



<h1 style="margin:auto;color:blue;text-align:center"> SHAURYA</h1>
<br><br><br><br><br><br>


<form name="Nameform">
   <!-- <form action="myphp.php" method="get"> -->
   
First name:<br>
<input type="text" name="fname"><br><br>
<input type="submit" value="submit">
</form>

</body>
</html>